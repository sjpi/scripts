# WordPress Deployment Tech Stack

## Core Components
- WordPress (latest stable version)
- PHP (latest stable version)
- MariaDB (latest stable version)
- Nginx or Apache (TBD)

## Performance Optimization
- PHP-FPM
- Redis (caching)
- LiteSpeed Cache
- Opcache

## Security
- Fail2ban
- SSL/TLS (Let's Encrypt or Cloudflare)
- Security headers
- SSH hardening

## Monitoring
- Prometheus
- Grafana
- System monitoring tools (glances, htop)

## Backup
- Duplicity or Rsync
- Remote storage (S3 or local)

## Additional Utilities
- curl
- wget
- git
- unzip
- nano